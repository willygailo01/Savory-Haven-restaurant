const CART_STORAGE_KEY = "cart";
const MENU_STORAGE_KEY = "menuItems";

const DEFAULT_MENU_ITEMS = [
  {
    id: "margherita-pizza",
    name: "Margherita Pizza",
    description: "Classic tomato sauce, mozzarella, basil leaves.",
    price: 12.99,
    image: "images/food1.jpg",
    category: "Pizza",
  },
  {
    id: "alfredo-pasta",
    name: "Creamy Alfredo Pasta",
    description: "Rich parmesan cream sauce with herbs and garlic.",
    price: 11.49,
    image: "images/alfredo.jpg",
    category: "Pasta",
  },
  {
    id: "grilled-steak-plate",
    name: "Grilled Steak Plate",
    description: "Premium grilled steak with butter vegetables.",
    price: 19.99,
    image: "images/food3.jpg",
    category: "Main Course",
  },
  {
    id: "spicy-chicken-burger",
    name: "Spicy Chicken Burger",
    description: "Crispy chicken patty, lettuce, and house sauce.",
    price: 9.75,
    image: "images/food4.jpg",
    category: "Burger",
  },
  {
    id: "garden-caesar-salad",
    name: "Garden Caesar Salad",
    description: "Fresh greens, croutons, parmesan, creamy dressing.",
    price: 8.49,
    image: "images/food5.jpg",
    category: "Salad",
  },
  {
    id: "chocolate-lava-cake",
    name: "Chocolate Lava Cake",
    description: "Warm chocolate center served with vanilla cream.",
    price: 6.99,
    image: "images/food6.jpg",
    category: "Dessert",
  },
];

function safeParse(value, fallback) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
}

function slugify(value) {
  return String(value)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function normalizeMenuItem(item, index) {
  if (!item || typeof item !== "object") {
    return null;
  }

  const name = String(item.name || "").trim();
  if (!name) {
    return null;
  }

  const parsedPrice = Number(item.price);

  return {
    id: String(item.id || `${slugify(name) || "menu-item"}-${index + 1}`),
    name,
    description: String(item.description || "").trim() || "Delicious house special.",
    price: Number.isFinite(parsedPrice) && parsedPrice > 0 ? Number(parsedPrice.toFixed(2)) : 0.01,
    image: String(item.image || "images/food1.jpg").trim() || "images/food1.jpg",
    category: String(item.category || "General").trim() || "General",
  };
}

function readMenuItems() {
  const parsed = safeParse(localStorage.getItem(MENU_STORAGE_KEY), []);
  const normalized = Array.isArray(parsed)
    ? parsed.map((item, index) => normalizeMenuItem(item, index)).filter(Boolean)
    : [];

  if (!normalized.length) {
    const defaults = DEFAULT_MENU_ITEMS.map((item) => ({ ...item }));
    localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(defaults));
    return defaults;
  }

  if (JSON.stringify(parsed) !== JSON.stringify(normalized)) {
    localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(normalized));
  }

  return normalized;
}

function readCart() {
  return safeParse(localStorage.getItem(CART_STORAGE_KEY), []);
}

function writeCart(cart) {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  window.dispatchEvent(new Event("cartUpdated"));
}

function formatPrice(amount) {
  return `$${amount.toFixed(2)}`;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => {
    const replacements = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    };
    return replacements[character] || character;
  });
}

function renderMenuCatalog() {
  const menuGrid = document.getElementById("menuGrid");
  if (!menuGrid) {
    return;
  }

  const menuItems = readMenuItems();
  menuGrid.innerHTML = "";

  if (!menuItems.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No menu items available right now.";
    menuGrid.appendChild(empty);
    return;
  }

  menuItems.forEach((item) => {
    const card = document.createElement("article");
    card.className = "menu-card";

    const image = document.createElement("img");
    image.src = item.image;
    image.alt = item.name;

    const body = document.createElement("div");
    body.className = "menu-card-body";

    const title = document.createElement("h3");
    title.textContent = item.name;

    const description = document.createElement("p");
    description.textContent = item.description;

    const meta = document.createElement("div");
    meta.className = "menu-meta";

    const price = document.createElement("span");
    price.textContent = formatPrice(item.price);

    const button = document.createElement("button");
    button.className = "btn btn-primary add-to-cart";
    button.type = "button";
    button.textContent = "Add to Cart";
    button.dataset.id = item.id;
    button.dataset.name = item.name;
    button.dataset.price = String(item.price);
    button.dataset.image = item.image;

    meta.appendChild(price);
    meta.appendChild(button);
    body.appendChild(title);
    body.appendChild(description);
    body.appendChild(meta);

    card.appendChild(image);
    card.appendChild(body);
    menuGrid.appendChild(card);
  });
}

function addItemToCart(item) {
  const cart = readCart();
  const existing = cart.find((entry) => entry.id === item.id);

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ ...item, quantity: 1 });
  }

  writeCart(cart);
}

function removeItemFromCart(itemId) {
  const cart = readCart().filter((item) => item.id !== itemId);
  writeCart(cart);
}

function changeItemQuantity(itemId, direction) {
  const cart = readCart();
  const target = cart.find((item) => item.id === itemId);

  if (!target) {
    return;
  }

  target.quantity += direction;

  if (target.quantity <= 0) {
    removeItemFromCart(itemId);
    return;
  }

  writeCart(cart);
}

function bindAddToCartButtons() {
  const buttons = document.querySelectorAll(".add-to-cart");
  if (!buttons.length) {
    return;
  }

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const item = {
        id: button.dataset.id,
        name: button.dataset.name,
        price: Number(button.dataset.price),
        image: button.dataset.image,
      };

      addItemToCart(item);
      const originalText = button.textContent;
      button.textContent = "Added";
      button.disabled = true;
      setTimeout(() => {
        button.textContent = originalText;
        button.disabled = false;
      }, 700);
    });
  });
}

function renderCartPage() {
  const tbody = document.getElementById("cartTableBody");
  const totalEl = document.getElementById("cartTotal");
  const emptyEl = document.getElementById("emptyCart");
  const tableWrap = document.getElementById("cartTableWrap");

  if (!tbody || !totalEl || !emptyEl || !tableWrap) {
    return;
  }

  const cart = readCart();

  if (!cart.length) {
    emptyEl.classList.remove("hidden");
    tableWrap.classList.add("hidden");
    totalEl.textContent = "$0.00";
    return;
  }

  emptyEl.classList.add("hidden");
  tableWrap.classList.remove("hidden");

  let total = 0;
  tbody.innerHTML = "";

  cart.forEach((item) => {
    const subtotal = item.price * item.quantity;
    total += subtotal;

    const safeName = escapeHTML(item.name);
    const safeImage = escapeHTML(item.image);

    const row = document.createElement("tr");
    row.innerHTML = `
      <td>
        <div class="cart-item-cell">
          <img src="${safeImage}" alt="${safeName}" />
          <span>${safeName}</span>
        </div>
      </td>
      <td>${formatPrice(item.price)}</td>
      <td>
        <div class="qty-controls">
          <button type="button" data-action="decrease" data-id="${item.id}">-</button>
          <span>${item.quantity}</span>
          <button type="button" data-action="increase" data-id="${item.id}">+</button>
        </div>
      </td>
      <td>${formatPrice(subtotal)}</td>
      <td>
        <button class="btn btn-secondary" type="button" data-action="remove" data-id="${item.id}">
          Remove
        </button>
      </td>
    `;
    tbody.appendChild(row);
  });

  totalEl.textContent = formatPrice(total);
}

function bindCartActions() {
  const tbody = document.getElementById("cartTableBody");
  const clearBtn = document.getElementById("clearCartBtn");

  if (!tbody) {
    return;
  }

  tbody.addEventListener("click", (event) => {
    const target = event.target.closest("button[data-action]");
    if (!target) {
      return;
    }

    const itemId = target.dataset.id;
    const action = target.dataset.action;

    if (action === "increase") {
      changeItemQuantity(itemId, 1);
    }

    if (action === "decrease") {
      changeItemQuantity(itemId, -1);
    }

    if (action === "remove") {
      removeItemFromCart(itemId);
    }

    renderCartPage();
  });

  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      writeCart([]);
      renderCartPage();
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  renderMenuCatalog();
  bindAddToCartButtons();
  bindCartActions();
  renderCartPage();
});

window.addEventListener("cartUpdated", renderCartPage);
