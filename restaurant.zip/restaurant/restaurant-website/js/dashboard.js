const DASH_USERS_KEY = "users";
const DASH_CURRENT_KEY = "currentUser";
const DASH_CART_KEY = "cart";
const MENU_ITEMS_KEY = "menuItems";

const DEFAULT_MENU_ITEMS = [
  {
    id: "margherita-pizza",
    name: "Margherita Pizza",
    description: "Classic tomato sauce, mozzarella, basil leaves.",
    price: 12.99,
    image: "images/food1.jpg",
    category: "Pizza",
  },
  {
    id: "alfredo-pasta",
    name: "Creamy Alfredo Pasta",
    description: "Rich parmesan cream sauce with herbs and garlic.",
    price: 11.49,
    image: "images/alfredo.jpg",
    category: "Pasta",
  },
  {
    id: "grilled-steak-plate",
    name: "Grilled Steak Plate",
    description: "Premium grilled steak with butter vegetables.",
    price: 19.99,
    image: "images/food3.jpg",
    category: "Main Course",
  },
  {
    id: "spicy-chicken-burger",
    name: "Spicy Chicken Burger",
    description: "Crispy chicken patty, lettuce, and house sauce.",
    price: 9.75,
    image: "images/food4.jpg",
    category: "Burger",
  },
  {
    id: "garden-caesar-salad",
    name: "Garden Caesar Salad",
    description: "Fresh greens, croutons, parmesan, creamy dressing.",
    price: 8.49,
    image: "images/food5.jpg",
    category: "Salad",
  },
  {
    id: "chocolate-lava-cake",
    name: "Chocolate Lava Cake",
    description: "Warm chocolate center served with vanilla cream.",
    price: 6.99,
    image: "images/food6.jpg",
    category: "Dessert",
  },
];

function parseData(value, fallback) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
}

function setData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function getDashboardUser() {
  return parseData(localStorage.getItem(DASH_CURRENT_KEY), null);
}

function getDashboardUsers() {
  const users = parseData(localStorage.getItem(DASH_USERS_KEY), []);
  return Array.isArray(users) ? users : [];
}

function getDashboardCart() {
  const cart = parseData(localStorage.getItem(DASH_CART_KEY), []);
  return Array.isArray(cart) ? cart : [];
}

function slugify(value) {
  return String(value)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function toMoney(amount) {
  return `$${Number(amount).toFixed(2)}`;
}

function toDateTime(date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function normalizeMenuItem(item, index) {
  if (!item || typeof item !== "object") {
    return null;
  }

  const name = String(item.name || "").trim();
  if (!name) {
    return null;
  }

  const parsedPrice = Number(item.price);
  const price = Number.isFinite(parsedPrice) && parsedPrice > 0 ? Number(parsedPrice.toFixed(2)) : 0.01;

  return {
    id: String(item.id || `${slugify(name) || "menu-item"}-${index + 1}`),
    name,
    description: String(item.description || "").trim() || "Delicious house special.",
    price,
    image: String(item.image || "images/food1.jpg").trim() || "images/food1.jpg",
    category: String(item.category || "General").trim() || "General",
  };
}

function getDefaultMenuItems() {
  return DEFAULT_MENU_ITEMS.map((item) => ({ ...item }));
}

function getMenuItems() {
  const parsed = parseData(localStorage.getItem(MENU_ITEMS_KEY), []);
  const normalized = Array.isArray(parsed)
    ? parsed.map((item, index) => normalizeMenuItem(item, index)).filter(Boolean)
    : [];

  if (!normalized.length) {
    const defaults = getDefaultMenuItems();
    setData(MENU_ITEMS_KEY, defaults);
    return defaults;
  }

  if (JSON.stringify(parsed) !== JSON.stringify(normalized)) {
    setData(MENU_ITEMS_KEY, normalized);
  }

  return normalized;
}

function saveMenuItems(items) {
  const normalized = (Array.isArray(items) ? items : [])
    .map((item, index) => normalizeMenuItem(item, index))
    .filter(Boolean);
  setData(MENU_ITEMS_KEY, normalized);
  return normalized;
}

function setStatus(target, message, isError) {
  const element = typeof target === "string" ? document.getElementById(target) : target;
  if (!element) {
    return;
  }

  element.textContent = message || "";
  element.classList.toggle("error", Boolean(isError));
}

function protectUserDashboard(user) {
  if (!user) {
    window.location.href = "login.html";
    return false;
  }

  if (user.role === "admin") {
    window.location.href = "admin-dashboard.html";
    return false;
  }

  return true;
}

function protectAdminDashboard(user) {
  if (!user) {
    window.location.href = "login.html";
    return false;
  }

  if (user.role !== "admin") {
    window.location.href = "user-dashboard.html";
    return false;
  }

  return true;
}

function renderUserDashboard(user) {
  const welcome = document.getElementById("userWelcome");
  const profileName = document.getElementById("profileName");
  const profileUsername = document.getElementById("profileUsername");
  const profileEmail = document.getElementById("profileEmail");
  const profileRole = document.getElementById("profileRole");
  const cartItemsEl = document.getElementById("dashboardCartItems");
  const cartTotalEl = document.getElementById("dashboardCartTotal");

  if (welcome) welcome.textContent = `Welcome, ${user.name || user.username}`;
  if (profileName) profileName.textContent = user.name || "-";
  if (profileUsername) profileUsername.textContent = user.username || "-";
  if (profileEmail) profileEmail.textContent = user.email || "-";
  if (profileRole) profileRole.textContent = user.role || "-";

  const cart = getDashboardCart();
  const itemCount = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const total = cart.reduce((sum, item) => sum + (item.price || 0) * (item.quantity || 0), 0);

  if (cartItemsEl) cartItemsEl.textContent = String(itemCount);
  if (cartTotalEl) cartTotalEl.textContent = toMoney(total);
}

function renderAdminStats(users, menuItems, cart) {
  const totalUsers = document.getElementById("totalUsers");
  const totalMenuItems = document.getElementById("totalMenuItems");
  const totalCartItems = document.getElementById("totalCartItems");
  const totalCartValue = document.getElementById("totalCartValue");
  const totalMenuItemsMeta = document.getElementById("totalMenuItemsMeta");
  const adminLastUpdated = document.getElementById("adminLastUpdated");

  const cartItems = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const cartValue = cart.reduce((sum, item) => sum + (item.price || 0) * (item.quantity || 0), 0);

  if (totalUsers) totalUsers.textContent = String(users.length);
  if (totalMenuItems) totalMenuItems.textContent = String(menuItems.length);
  if (totalCartItems) totalCartItems.textContent = String(cartItems);
  if (totalCartValue) totalCartValue.textContent = toMoney(cartValue);
  if (totalMenuItemsMeta) totalMenuItemsMeta.textContent = String(menuItems.length);
  if (adminLastUpdated) adminLastUpdated.textContent = toDateTime(new Date());
}

function createTableCell(text) {
  const cell = document.createElement("td");
  cell.textContent = text;
  return cell;
}

function renderUsersTable(users, searchTerm) {
  const usersTableBody = document.getElementById("usersTableBody");
  if (!usersTableBody) {
    return;
  }

  const term = String(searchTerm || "")
    .trim()
    .toLowerCase();
  const filteredUsers = users.filter((user) => {
    const record = `${user.name || ""} ${user.username || ""} ${user.email || ""}`.toLowerCase();
    return record.includes(term);
  });

  usersTableBody.innerHTML = "";

  if (!filteredUsers.length) {
    const row = document.createElement("tr");
    row.className = "empty-row";
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.textContent = "No users match your search.";
    row.appendChild(cell);
    usersTableBody.appendChild(row);
    return;
  }

  filteredUsers.forEach((user) => {
    const row = document.createElement("tr");
    row.appendChild(createTableCell(user.name || "-"));
    row.appendChild(createTableCell(user.username || "-"));
    row.appendChild(createTableCell(user.email || "-"));

    const roleCell = document.createElement("td");
    const roleTag = document.createElement("span");
    roleTag.className = "tag";
    roleTag.textContent = user.role || "user";
    roleCell.appendChild(roleTag);
    row.appendChild(roleCell);

    const actionCell = document.createElement("td");
    actionCell.className = "actions-cell";
    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "btn btn-secondary btn-small danger-btn";
    removeBtn.dataset.action = "remove-user";
    removeBtn.dataset.userId = String(user.id);
    removeBtn.textContent = "Delete";
    actionCell.appendChild(removeBtn);
    row.appendChild(actionCell);

    usersTableBody.appendChild(row);
  });
}

function renderMenuTable(menuItems) {
  const menuTableBody = document.getElementById("menuTableBody");
  if (!menuTableBody) {
    return;
  }

  menuTableBody.innerHTML = "";

  if (!menuItems.length) {
    const row = document.createElement("tr");
    row.className = "empty-row";
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.textContent = "No menu items available.";
    row.appendChild(cell);
    menuTableBody.appendChild(row);
    return;
  }

  menuItems.forEach((item) => {
    const row = document.createElement("tr");

    const nameCell = document.createElement("td");
    const title = document.createElement("strong");
    title.textContent = item.name;
    const description = document.createElement("p");
    description.className = "muted small-text table-subtext";
    description.textContent = item.description;
    nameCell.appendChild(title);
    nameCell.appendChild(description);

    const categoryCell = document.createElement("td");
    const categoryTag = document.createElement("span");
    categoryTag.className = "tag";
    categoryTag.textContent = item.category;
    categoryCell.appendChild(categoryTag);

    const priceCell = createTableCell(toMoney(item.price));

    const imageCell = document.createElement("td");
    const imageWrap = document.createElement("div");
    imageWrap.className = "image-cell";
    const thumb = document.createElement("img");
    thumb.className = "menu-thumb";
    thumb.src = item.image;
    thumb.alt = item.name;
    const imagePath = document.createElement("span");
    imagePath.className = "small-text muted";
    imagePath.textContent = item.image;
    imageWrap.appendChild(thumb);
    imageWrap.appendChild(imagePath);
    imageCell.appendChild(imageWrap);

    const actionCell = document.createElement("td");
    actionCell.className = "actions-cell";

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "btn btn-secondary btn-small";
    editBtn.dataset.action = "edit-menu";
    editBtn.dataset.itemId = item.id;
    editBtn.textContent = "Edit";

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "btn btn-secondary btn-small danger-btn";
    deleteBtn.dataset.action = "delete-menu";
    deleteBtn.dataset.itemId = item.id;
    deleteBtn.textContent = "Delete";

    actionCell.appendChild(editBtn);
    actionCell.appendChild(deleteBtn);

    row.appendChild(nameCell);
    row.appendChild(categoryCell);
    row.appendChild(priceCell);
    row.appendChild(imageCell);
    row.appendChild(actionCell);

    menuTableBody.appendChild(row);
  });
}

function refreshAdminDashboard() {
  const users = getDashboardUsers();
  const menuItems = getMenuItems();
  const cart = getDashboardCart();
  const searchInput = document.getElementById("userSearchInput");

  renderAdminStats(users, menuItems, cart);
  renderUsersTable(users, searchInput ? searchInput.value : "");
  renderMenuTable(menuItems);
}

function populateMenuForm(item) {
  const editId = document.getElementById("menuEditId");
  const name = document.getElementById("menuName");
  const category = document.getElementById("menuCategory");
  const price = document.getElementById("menuPrice");
  const image = document.getElementById("menuImage");
  const description = document.getElementById("menuDescription");
  const saveBtn = document.getElementById("menuSaveBtn");

  if (!editId || !name || !category || !price || !image || !description || !saveBtn) {
    return;
  }

  editId.value = item.id;
  name.value = item.name;
  category.value = item.category;
  price.value = String(item.price);
  image.value = item.image;
  description.value = item.description;
  saveBtn.textContent = "Update Menu Item";
}

function resetMenuForm(clearStatus) {
  const form = document.getElementById("menuForm");
  const editId = document.getElementById("menuEditId");
  const saveBtn = document.getElementById("menuSaveBtn");
  const shouldClearStatus = clearStatus !== false;

  if (form) {
    form.reset();
  }

  if (editId) {
    editId.value = "";
  }

  if (saveBtn) {
    saveBtn.textContent = "Save Menu Item";
  }

  if (shouldClearStatus) {
    setStatus("menuFormStatus", "", false);
  }
}

function createUniqueMenuId(name, existingIds) {
  const base = slugify(name) || "menu-item";
  let candidate = base;
  let count = 2;

  while (existingIds.has(candidate)) {
    candidate = `${base}-${count}`;
    count += 1;
  }

  return candidate;
}

function pruneCart(menuItems) {
  const allowedIds = new Set(menuItems.map((item) => item.id));
  const cart = getDashboardCart();
  const nextCart = cart.filter((item) => allowedIds.has(item.id));

  if (nextCart.length !== cart.length) {
    setData(DASH_CART_KEY, nextCart);
  }
}

function exportUsers() {
  const users = getDashboardUsers();

  if (!users.length) {
    setStatus("adminStatus", "No users to export.", true);
    return;
  }

  const exportableUsers = users.map((user) => ({
    id: user.id || null,
    name: user.name || "",
    username: user.username || "",
    email: user.email || "",
    role: user.role || "user",
  }));

  const date = new Date().toISOString().slice(0, 10);
  const blob = new Blob([JSON.stringify(exportableUsers, null, 2)], {
    type: "application/json",
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `users-export-${date}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  setStatus("adminStatus", "Users exported successfully.", false);
}

function bindAdminDashboardEvents() {
  const userSearchInput = document.getElementById("userSearchInput");
  const usersTableBody = document.getElementById("usersTableBody");
  const exportUsersBtn = document.getElementById("exportUsersBtn");
  const menuForm = document.getElementById("menuForm");
  const menuResetBtn = document.getElementById("menuResetBtn");
  const menuTableBody = document.getElementById("menuTableBody");
  const refreshAdminDataBtn = document.getElementById("refreshAdminDataBtn");
  const clearAllCartsBtn = document.getElementById("clearAllCartsBtn");
  const resetMenuBtn = document.getElementById("resetMenuBtn");

  if (userSearchInput) {
    userSearchInput.addEventListener("input", () => {
      renderUsersTable(getDashboardUsers(), userSearchInput.value);
    });
  }

  if (usersTableBody) {
    usersTableBody.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-action='remove-user']");
      if (!button) {
        return;
      }

      const userId = button.dataset.userId;
      const users = getDashboardUsers();
      const target = users.find((user) => String(user.id) === String(userId));

      if (!target) {
        return;
      }

      const ok = window.confirm(`Delete user \"${target.username || target.name}\"?`);
      if (!ok) {
        return;
      }

      const nextUsers = users.filter((user) => String(user.id) !== String(userId));
      setData(DASH_USERS_KEY, nextUsers);
      setStatus("adminStatus", `User ${target.username || target.name} removed.`, false);
      refreshAdminDashboard();
    });
  }

  if (exportUsersBtn) {
    exportUsersBtn.addEventListener("click", exportUsers);
  }

  if (menuForm) {
    menuForm.addEventListener("submit", (event) => {
      event.preventDefault();

      const editId = document.getElementById("menuEditId");
      const name = document.getElementById("menuName");
      const category = document.getElementById("menuCategory");
      const price = document.getElementById("menuPrice");
      const image = document.getElementById("menuImage");
      const description = document.getElementById("menuDescription");

      const itemName = name ? name.value.trim() : "";
      const itemCategory = category ? category.value.trim() : "";
      const itemPrice = Number(price ? price.value : 0);
      const itemImage = image ? image.value.trim() : "";
      const itemDescription = description ? description.value.trim() : "";

      if (!itemName || !itemCategory || !itemImage || !itemDescription || !Number.isFinite(itemPrice) || itemPrice <= 0) {
        setStatus("menuFormStatus", "Please fill all menu fields with valid values.", true);
        return;
      }

      let menuItems = getMenuItems();
      const editingId = editId ? editId.value : "";

      if (editingId) {
        const index = menuItems.findIndex((item) => item.id === editingId);

        if (index === -1) {
          setStatus("menuFormStatus", "Item not found for update.", true);
          return;
        }

        menuItems[index] = {
          ...menuItems[index],
          name: itemName,
          category: itemCategory,
          price: Number(itemPrice.toFixed(2)),
          image: itemImage,
          description: itemDescription,
        };

        menuItems = saveMenuItems(menuItems);
        setStatus("menuFormStatus", "Menu item updated.", false);
      } else {
        const existingIds = new Set(menuItems.map((item) => item.id));
        const newItem = {
          id: createUniqueMenuId(itemName, existingIds),
          name: itemName,
          category: itemCategory,
          price: Number(itemPrice.toFixed(2)),
          image: itemImage,
          description: itemDescription,
        };

        menuItems.push(newItem);
        menuItems = saveMenuItems(menuItems);
        setStatus("menuFormStatus", "New menu item added.", false);
      }

      pruneCart(menuItems);
      refreshAdminDashboard();
      resetMenuForm(false);
    });
  }

  if (menuResetBtn) {
    menuResetBtn.addEventListener("click", resetMenuForm);
  }

  if (menuTableBody) {
    menuTableBody.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-action]");
      if (!button) {
        return;
      }

      const itemId = button.dataset.itemId;
      const action = button.dataset.action;
      let menuItems = getMenuItems();
      const targetItem = menuItems.find((item) => item.id === itemId);

      if (!targetItem) {
        return;
      }

      if (action === "edit-menu") {
        populateMenuForm(targetItem);
        setStatus("menuFormStatus", "Editing selected item.", false);
        return;
      }

      if (action === "delete-menu") {
        const ok = window.confirm(`Delete menu item \"${targetItem.name}\"?`);
        if (!ok) {
          return;
        }

        menuItems = menuItems.filter((item) => item.id !== itemId);
        menuItems = saveMenuItems(menuItems);
        pruneCart(menuItems);
        resetMenuForm();
        setStatus("adminStatus", `${targetItem.name} removed from menu.`, false);
        refreshAdminDashboard();
      }
    });
  }

  if (refreshAdminDataBtn) {
    refreshAdminDataBtn.addEventListener("click", () => {
      refreshAdminDashboard();
      setStatus("adminStatus", "Dashboard refreshed.", false);
    });
  }

  if (clearAllCartsBtn) {
    clearAllCartsBtn.addEventListener("click", () => {
      const ok = window.confirm("Clear all items currently stored in cart?");
      if (!ok) {
        return;
      }

      setData(DASH_CART_KEY, []);
      refreshAdminDashboard();
      setStatus("adminStatus", "Cart data cleared.", false);
    });
  }

  if (resetMenuBtn) {
    resetMenuBtn.addEventListener("click", () => {
      const ok = window.confirm("Reset menu to default items?");
      if (!ok) {
        return;
      }

      const defaults = getDefaultMenuItems();
      saveMenuItems(defaults);
      pruneCart(defaults);
      resetMenuForm();
      refreshAdminDashboard();
      setStatus("adminStatus", "Menu reset to defaults.", false);
    });
  }

  window.addEventListener("storage", () => {
    refreshAdminDashboard();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const user = getDashboardUser();
  const page = window.location.pathname.split("/").pop();

  if (page === "user-dashboard.html") {
    if (!protectUserDashboard(user)) {
      return;
    }

    renderUserDashboard(user);
  }

  if (page === "admin-dashboard.html") {
    if (!protectAdminDashboard(user)) {
      return;
    }

    const welcome = document.getElementById("adminWelcome");
    if (welcome) {
      welcome.textContent = "Welcome, Administrator";
    }

    getMenuItems();
    bindAdminDashboardEvents();
    refreshAdminDashboard();
  }
});
