const USERS_KEY = "users";
const CURRENT_USER_KEY = "currentUser";
const CART_KEY = "cart";

function parseJSON(value, fallback) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
}

function getCurrentUser() {
  return parseJSON(localStorage.getItem(CURRENT_USER_KEY), null);
}

function getUsers() {
  return parseJSON(localStorage.getItem(USERS_KEY), []);
}

function getCart() {
  return parseJSON(localStorage.getItem(CART_KEY), []);
}

function setActiveNavLink() {
  const currentPage = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".main-nav a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === currentPage) {
      link.classList.add("active");
    }
  });
}

function updateYear() {
  const yearEl = document.getElementById("year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

function updateCartBadge() {
  const badge = document.getElementById("cartCount");
  if (!badge) {
    return;
  }

  const count = getCart().reduce((sum, item) => sum + (item.quantity || 0), 0);
  badge.textContent = String(count);
}

function renderAuthNav() {
  const user = getCurrentUser();
  const loginLink = document.querySelector('[data-auth="login"]');
  const registerLink = document.querySelector('[data-auth="register"]');
  const dashboardLink = document.getElementById("dashboardLink");
  const logoutBtn = document.getElementById("logoutBtn");

  if (!dashboardLink || !logoutBtn || !loginLink || !registerLink) {
    return;
  }

  if (user) {
    loginLink.classList.add("hidden");
    registerLink.classList.add("hidden");
    dashboardLink.classList.remove("hidden");
    logoutBtn.classList.remove("hidden");

    if (user.role === "admin") {
      dashboardLink.href = "admin-dashboard.html";
      dashboardLink.textContent = "Admin Dashboard";
    } else {
      dashboardLink.href = "user-dashboard.html";
      dashboardLink.textContent = "Dashboard";
    }
  } else {
    loginLink.classList.remove("hidden");
    registerLink.classList.remove("hidden");
    dashboardLink.classList.add("hidden");
    logoutBtn.classList.add("hidden");
  }
}

function setupLogout() {
  const logoutBtn = document.getElementById("logoutBtn");
  if (!logoutBtn) {
    return;
  }

  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem(CURRENT_USER_KEY);
    window.location.href = "login.html";
  });
}

function setupNavigationToggle() {
  const toggleBtn = document.getElementById("navToggle");
  const nav = document.getElementById("mainNav");

  if (!toggleBtn || !nav) {
    return;
  }

  toggleBtn.addEventListener("click", () => {
    nav.classList.toggle("open");
  });

  nav.querySelectorAll("a, button").forEach((link) => {
    link.addEventListener("click", () => nav.classList.remove("open"));
  });
}

function setupContactForm() {
  const form = document.getElementById("contactForm");
  const status = document.getElementById("contactStatus");

  if (!form || !status) {
    return;
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    status.classList.remove("error");
    status.textContent = "Message sent successfully. We will contact you soon.";
    form.reset();
  });
}

window.AppState = {
  getUsers,
  getCurrentUser,
  getCart,
  USERS_KEY,
  CURRENT_USER_KEY,
  CART_KEY,
};

document.addEventListener("DOMContentLoaded", () => {
  updateYear();
  renderAuthNav();
  setActiveNavLink();
  updateCartBadge();
  setupLogout();
  setupNavigationToggle();
  setupContactForm();
});

window.addEventListener("cartUpdated", updateCartBadge);
window.addEventListener("storage", (event) => {
  if (event.key === CURRENT_USER_KEY || event.key === CART_KEY) {
    updateCartBadge();
    renderAuthNav();
    setActiveNavLink();
  }
});
