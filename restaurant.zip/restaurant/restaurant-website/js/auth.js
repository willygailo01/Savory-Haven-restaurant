const USERS_STORAGE_KEY = "users";
const CURRENT_STORAGE_KEY = "currentUser";
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "admin123";

function parseValue(value, fallback) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
}

function getStoredUsers() {
  return parseValue(localStorage.getItem(USERS_STORAGE_KEY), []);
}

function saveUsers(users) {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}

function saveCurrentUser(user) {
  localStorage.setItem(CURRENT_STORAGE_KEY, JSON.stringify(user));
}

function showStatus(element, message, isError) {
  if (!element) {
    return;
  }

  element.textContent = message;
  element.classList.toggle("error", Boolean(isError));
}

function handleRegister() {
  const form = document.getElementById("registerForm");
  const status = document.getElementById("registerStatus");

  if (!form) {
    return;
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const formData = new FormData(form);
    const name = String(formData.get("name") || "").trim();
    const username = String(formData.get("username") || "").trim().toLowerCase();
    const email = String(formData.get("email") || "").trim().toLowerCase();
    const password = String(formData.get("password") || "").trim();

    if (!name || !username || !email || !password) {
      showStatus(status, "Please fill all required fields.", true);
      return;
    }

    if (username === ADMIN_USERNAME) {
      showStatus(status, "This username is reserved.", true);
      return;
    }

    const users = getStoredUsers();
    const exists = users.some(
      (user) => user.username.toLowerCase() === username || user.email.toLowerCase() === email
    );

    if (exists) {
      showStatus(status, "Username or email already exists.", true);
      return;
    }

    const newUser = {
      id: Date.now(),
      name,
      username,
      email,
      password,
      role: "user",
    };

    users.push(newUser);
    saveUsers(users);
    saveCurrentUser({
      id: newUser.id,
      name: newUser.name,
      username: newUser.username,
      email: newUser.email,
      role: newUser.role,
    });

    showStatus(status, "Registration successful. Redirecting to your dashboard...", false);
    form.reset();

    setTimeout(() => {
      window.location.href = "user-dashboard.html";
    }, 650);
  });
}

function handleLogin() {
  const form = document.getElementById("loginForm");
  const status = document.getElementById("loginStatus");

  if (!form) {
    return;
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const formData = new FormData(form);
    const username = String(formData.get("username") || "").trim().toLowerCase();
    const password = String(formData.get("password") || "").trim();

    if (!username || !password) {
      showStatus(status, "Please enter username and password.", true);
      return;
    }

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      saveCurrentUser({
        id: "admin",
        name: "Administrator",
        username: ADMIN_USERNAME,
        role: "admin",
      });

      showStatus(status, "Admin login successful. Redirecting...", false);
      form.reset();

      setTimeout(() => {
        window.location.href = "admin-dashboard.html";
      }, 550);
      return;
    }

    const users = getStoredUsers();
    const matchedUser = users.find(
      (user) => user.username.toLowerCase() === username && user.password === password
    );

    if (!matchedUser) {
      showStatus(status, "Invalid credentials.", true);
      return;
    }

    saveCurrentUser({
      id: matchedUser.id,
      name: matchedUser.name,
      username: matchedUser.username,
      email: matchedUser.email,
      role: "user",
    });

    showStatus(status, "Login successful. Redirecting...", false);
    form.reset();

    setTimeout(() => {
      window.location.href = "user-dashboard.html";
    }, 550);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (!localStorage.getItem(USERS_STORAGE_KEY)) {
    saveUsers([]);
  }

  handleRegister();
  handleLogin();
});
